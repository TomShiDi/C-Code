package com.tom.sell.reopsitory;

import com.tom.sell.entity.Girl;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GirlRepository extends JpaRepository<Girl,Integer>
{
    //拓展，根据年龄查询信息
    public List<Girl> findByAge(Integer age);
}
