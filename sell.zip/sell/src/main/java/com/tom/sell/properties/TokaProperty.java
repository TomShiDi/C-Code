package com.tom.sell.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

//@Service
//@PropertySource("application.yml")
//@ConfigurationProperties(prefix = "toka-t")
public class TokaProperty {
//    private String name;
//
//    public void setName(String name)
//    {
//        this.name=name;
//    }
//
//    public String getName()
//    {
//        return name;
//    }
//
//    public String say()
//    {
//        return name;
//    }

}
