package com.tom.sell.controller;

import com.tom.sell.entity.Girl;
import com.tom.sell.reopsitory.GirlRepository;
import com.tom.sell.service.GirlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class GirlController
{
    @Autowired
    private GirlRepository girlRepository;
    @Autowired
    private GirlService girlService;
    /**
     *查询所有女生列表
     */
    @RequestMapping(value = "/girl")
    public  List<Girl> girllist()
    {
        return girlRepository.findAll();
    }

    /**
     * 添加一条女生数据
     * @return
     */
    @PostMapping(value = "/girl")
    public Girl girlAdd(Girl girl)
    {
        girl.setCupSize(girl.getCupSize());
        girl.setName(girl.getName());

        return girlRepository.save(girl);
    }

    //查询一个女生
    @GetMapping(value = "/girl/{id}")
    public Optional<Girl> girlGet(@PathVariable("id") Integer id)
    {
        return girlRepository.findById(id);
    }
    //更新信息
    @PutMapping(value = "/girl/{id}")
    public void girlUpdate(@PathVariable("id") Integer id,@RequestParam("cupSize") String cupSize,
                           @RequestParam("name") String name)
    {
        Girl girl=new Girl();
        girl.setId(id);
        girl.setName(name);
        girl.setCupSize(cupSize);
        girlRepository.save(girl);
    }

    //删除信息
    @DeleteMapping(value = "/girl/{id}")
    public void girlDelete(@PathVariable("id") Integer id)
    {
       girlRepository.deleteById(id);
    }

    //根据年龄查询信息
    @PutMapping(value = "/girl/age/{age}")
    public List<Girl> girlFindByAge(@PathVariable("age") Integer age)
    {
        return  girlRepository.findByAge(age);
    }
    //同时插入或同时都不插入两条数据
    @PutMapping(value = "/girl/two")
    public void girlTwoInsert()
    {
        girlService.insertTwo();
    }
}
