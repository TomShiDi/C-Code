package com.tom.sell.entity;


import javax.persistence.*;

@Entity//表示当前类对应数据库的一个表
@Table(name = "girl")
public class Girl {
    @Id
    @GeneratedValue
    private Integer id;
    @Column(name = "cupSize")
    private String cupSize;
    @Column(name = "name")
    private String name;
    @Column(name="age")
    private Integer age;

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }



    public Girl() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCupSize() {
        return cupSize;
    }

    public void setCupSize(String cupSize) {
        this.cupSize = cupSize;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
