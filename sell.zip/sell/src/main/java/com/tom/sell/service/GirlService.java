package com.tom.sell.service;

import com.tom.sell.entity.Girl;
import com.tom.sell.reopsitory.GirlRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class GirlService {
    private Girl girl_1=new Girl();
    private Girl girl_2=new Girl();
    @Autowired
    private GirlRepository girlRepository;
    @Transactional//同时成功或同时失败
    public void insertTwo()
    {
        girl_1.setCupSize("AAAAAAA");
        girl_1.setAge(14);
        girl_1.setId(5);
        girl_2.setCupSize("C");
        girl_2.setAge(15);
        girl_2.setId(6);
        girlRepository.save(girl_1);
        girlRepository.save(girl_2);
    }
}

