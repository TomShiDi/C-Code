package com.tom.sell.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@RestController
public class HelloController {

//    @Value("${CupSize}")
//    private String CupSize;
//    @Autowired
//    private TokaProperty tokaProperty;
//
//    @RequestMapping(value = "Toka",method = RequestMethod.GET)
//    public String  Toka()
//    {
//        return tokaProperty.getName();
//    }
//    获取URL参数方法一
//    @RequestMapping(value = "/say/{id}",method = RequestMethod.GET)
//    public String say(@PathVariable("id") Integer myId)
//    {
//        return "id"+myId;
//    }
//    获取URL参数方法二
//    @RequestMapping(value = "/say",method = RequestMethod.GET)
//    public String say(@RequestParam(value = "id",required = false,defaultValue = "100") Integer myId)
//    {
//        return "id: "+myId;
//    }

}

